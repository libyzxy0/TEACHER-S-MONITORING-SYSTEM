<?php
// Redirect to index.php
header("Location: index.php");
exit();
?>

